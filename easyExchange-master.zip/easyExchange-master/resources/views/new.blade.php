
<a href="{{ url('reset')}}">Reset my Password</a>