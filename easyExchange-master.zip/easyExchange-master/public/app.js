// Declaration du l application 
var app = angular.module("easyExchange",['ngRoute'])