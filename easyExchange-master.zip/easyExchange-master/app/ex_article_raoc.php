<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ex_article_raoc extends Model
{
    //
}
