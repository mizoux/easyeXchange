<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ex_devise extends Model
{
    //
}
