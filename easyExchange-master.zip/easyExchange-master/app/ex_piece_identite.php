<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ex_piece_identite extends Model
{
    //
}
