<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ex_compte_ftp extends Model
{
    //
}
